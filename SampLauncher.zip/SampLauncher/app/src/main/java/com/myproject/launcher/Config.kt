package com.myproject.launcher

object Config {
    // Ссылка на твой config.json (хостинг, GitHub Pages, Raw-ссылка и т.д.)
    const val CONFIG_URL = "https://example.com/launcher/config.json"
    // Пакет установленного клиента игры
    const val GAME_PACKAGE = "com.yourproject.game"
}
