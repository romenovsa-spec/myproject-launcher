package com.myproject.launcher

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var online: TextView
    private lateinit var news: TextView
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var nick: EditText
    private lateinit var play: Button
    private var cfg: JSONObject? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF121212.toInt())
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(tv("MY PROJECT", 28f, Color.WHITE).apply { gravity = Gravity.CENTER })
        online = tv("Онлайн: ...", 16f, 0xFF4CAF50.toInt()).apply { gravity = Gravity.CENTER }
        root.addView(online)

        news = tv("Загрузка новостей...", 14f, 0xFFCCCCCC.toInt())
        root.addView(ScrollView(this).apply { addView(news); setPadding(0, dp(16), 0, dp(16)) },
            LinearLayout.LayoutParams(-1, 0, 1f))

        nick = EditText(this).apply {
            hint = "Ник (Name_Surname)"
            setHintTextColor(0xFF777777.toInt()); setTextColor(Color.WHITE)
            setSingleLine(true)
            setText(getPreferences(MODE_PRIVATE).getString("nick", ""))
        }
        root.addView(nick)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar)
        status = tv("", 13f, 0xFF999999.toInt())
        root.addView(status)
        play = Button(this).apply { text = "ИГРАТЬ"; setOnClickListener { onPlay() } }
        root.addView(play)
        setContentView(root)
        loadConfig()
    }

    private fun ui(f: () -> Unit) = runOnUiThread(f)

    private fun loadConfig() = Thread {
        try {
            val c = JSONObject(Net.get(Config.CONFIG_URL)); cfg = c
            val arr = c.optJSONArray("news")
            val sb = StringBuilder()
            if (arr != null) for (i in 0 until arr.length()) {
                val n = arr.getJSONObject(i)
                sb.append(n.optString("title")).append("\n").append(n.optString("text")).append("\n\n")
            }
            ui { news.text = sb.toString().ifBlank { "Новостей пока нет" } }
            val s = c.getJSONObject("server")
            val o = Net.sampOnline(s.getString("ip"), s.optInt("port", 7777))
            ui { online.text = if (o != null) "Онлайн: ${o.first} / ${o.second}" else "Сервер недоступен" }
        } catch (e: Exception) {
            ui { status.text = "Нет связи с сервером лаунчера" }
        }
    }.start()

    private fun onPlay() {
        val name = nick.text.toString().trim()
        if (name.length < 3) { status.text = "Введи ник"; return }
        getPreferences(MODE_PRIVATE).edit().putString("nick", name).apply()
        val c = cfg ?: run { status.text = "Конфиг не загружен"; return }
        play.isEnabled = false
        Thread {
            try {
                val base = getExternalFilesDir(null)!!
                val files = c.optJSONArray("files")
                if (files != null) for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i)
                    val dest = File(base, f.getString("path"))
                    val md5 = f.optString("md5")
                    if (dest.exists() && (md5.isEmpty() || Net.md5(dest).equals(md5, true))) continue
                    ui { status.text = "Скачивание ${i + 1}/${files.length()}: ${f.getString("path")}" }
                    Net.download(f.getString("url"), dest) { d, t ->
                        if (t > 0) ui { bar.progress = (d * 100 / t).toInt() }
                    }
                }
                ui { status.text = "Запуск..."; bar.progress = 100; launch(name, c.getJSONObject("server")) }
            } catch (e: Exception) {
                ui { status.text = "Ошибка: ${e.message}" }
            }
            ui { play.isEnabled = true }
        }.start()
    }

    private fun launch(name: String, s: JSONObject) {
        val i = packageManager.getLaunchIntentForPackage(Config.GAME_PACKAGE)
        if (i == null) { status.text = "Клиент игры не установлен"; return }
        i.putExtra("nickname", name)
        i.putExtra("ip", s.getString("ip"))
        i.putExtra("port", s.optInt("port", 7777))
        startActivity(i)
    }
}
