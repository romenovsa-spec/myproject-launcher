package com.myproject.launcher

import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.security.MessageDigest

object Net {
    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 15000
        return c
    }

    fun get(url: String): String =
        open(url).inputStream.bufferedReader().use { it.readText() }

    fun md5(f: File): String {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().use { ins ->
            val b = ByteArray(8192)
            while (true) {
                val n = ins.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val c = open(url)
        val total = c.contentLengthLong
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        c.inputStream.use { i ->
            tmp.outputStream().use { o ->
                val b = ByteArray(16384)
                var done = 0L
                while (true) {
                    val n = i.read(b)
                    if (n < 0) break
                    o.write(b, 0, n)
                    done += n
                    onProgress(done, total)
                }
            }
        }
        if (dest.exists()) dest.delete()
        tmp.renameTo(dest)
    }

    /** Онлайн сервера по протоколу SA:MP query. Возвращает (игроки, максимум) или null. */
    fun sampOnline(host: String, port: Int): Pair<Int, Int>? = try {
        val addr = InetAddress.getByName(host)
        val ip = addr.address
        val req = byteArrayOf('S'.code.toByte(), 'A'.code.toByte(), 'M'.code.toByte(), 'P'.code.toByte()) +
                ip + byteArrayOf((port and 0xFF).toByte(), (port shr 8 and 0xFF).toByte(), 'i'.code.toByte())
        DatagramSocket().use { s ->
            s.soTimeout = 2500
            s.send(DatagramPacket(req, req.size, addr, port))
            val buf = ByteArray(512)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            val players = (buf[12].toInt() and 0xFF) or ((buf[13].toInt() and 0xFF) shl 8)
            val max = (buf[14].toInt() and 0xFF) or ((buf[15].toInt() and 0xFF) shl 8)
            Pair(players, max)
        }
    } catch (e: Exception) { null }
}
